#! /bin/sh

# Copyright (c) 2014-2021 Passware

### BEGIN INIT INFO
# Provides:          passware-kit-agent
# Required-Start:    $remote_fs $syslog
# Required-Stop:     $remote_fs $syslog
# Default-Start:     2 3 4 5
# Default-Stop:      0 1 6
# Short-Description: Starts the Passware Kit Agent as a daemon
### END INIT INFO

PATH=/sbin:/usr/sbin:/bin:/usr/bin

DESC="Passware Kit Agent"
NAME=agentwrapper.sh		# cutted to 15 chars in /proc/%d/stat
WORKDIR=/home/user
DAEMON=`readlink -f $WORKDIR/$NAME`
DAEMON_ARGS=""
PIDFILE=/var/run/$NAME.pid

test -x $DAEMON || { logger -i -s -t $0 "Error: $DAEMON not found or not executable"; exit 5; }

. /lib/init/vars.sh	  # Load the VERBOSE setting and other rcS variables
. /lib/lsb/init-functions # Load log_* and status_of_proc functions

agent_start()
{
	CMD="start-stop-daemon --start --quiet --background --chdir $WORKDIR"
	CMD="$CMD --make-pidfile --pidfile $PIDFILE --exec $DAEMON"

	$CMD --test > /dev/null || return 1
	$CMD -- $DAEMON_ARGS    || return 2
}

agent_stop()
{
	local RETVAL

	[ "$VERBOSE" != no ] && log_daemon_msg "Stopping $DESC"
	
	start-stop-daemon --stop --quiet --retry=TERM/30/KILL/5 --oknodo \
		--pidfile $PIDFILE --name $NAME
	RETVAL=$?
	rm -f $PIDFILE

	case "$RETVAL" in
		0|1) [ "$VERBOSE" != no ] && log_end_msg 0 ;;
		2) [ "$VERBOSE" != no ] && log_end_msg 1 ;;
	esac

	return $RETVAL
}

case "$1" in
  start)
	[ "$VERBOSE" != no ] && log_daemon_msg "Starting $DESC"
	agent_start
	case "$?" in
		0|1) [ "$VERBOSE" != no ] && log_end_msg 0 ;;
		2) [ "$VERBOSE" != no ] && log_end_msg 1 ;;
	esac
	;;
  stop)
	agent_stop
	;;
  status)
	status_of_proc "$DAEMON" "$DESC" && exit 0 || exit $?
	;;
  restart)
	agent_stop
	case "$?" in
	  0|1)
		log_daemon_msg "Restarting $DESC"
		agent_start
		case "$?" in
			0) log_end_msg 0 ;;
			1) log_end_msg 1 ;; # Old process is still running
			*) log_end_msg 1 ;; # Failed to start
		esac
		;;
	  *)
	  	# Failed to stop
		;;
	esac
	;;
  reload)
	log_daemon_msg "Reloading $DESC"
	start-stop-daemon --stop --signal 1 --quiet --pidfile $PIDFILE --name $NAME
	log_end_msg $?
	;;
  *)
	echo "Usage: $0 {start|stop|status|reload|restart}" >&2
	exit 3
	;;
esac

exit 0
