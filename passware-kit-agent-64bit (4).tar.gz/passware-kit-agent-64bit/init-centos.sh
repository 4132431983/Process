#! /bin/sh

# Copyright (c) 2014-2021 Passware

### BEGIN INIT INFO
# Provides:          passware-kit-agent
# Required-Start:    $remote_fs $syslog
# Required-Stop:     $remote_fs $syslog
# Default-Start:     2 3 4 5
# Default-Stop:      0 1 6
# Short-Description: Starts the Passware Kit Agent as a daemon
### END INIT INFO

. /etc/init.d/functions

PATH=/sbin:/usr/sbin:/bin:/usr/bin

DESC="Passware Kit Agent"
NAME=agentwrapper.sh			# cutted to 15 chars in /proc/%d/stat
WORKDIR=/home/user
DAEMON=`readlink -f $WORKDIR/$NAME`
DAEMON_ARGS=""
PIDFILE=/var/run/$NAME.pid
DAEMON_COREFILE_LIMIT="unlimited"	# daemon() function defaults to 0

# Allow admin to redefine above vars in RH's central place
if [ -f /etc/sysconfig/$NAME ]; then
	. /etc/sysconfig/$NAME
fi

test -x $DAEMON || { logger -i -s -t $0 "Error: $DAEMON not found or not executable"; exit 5; }

RETVAL=0

agent_start()
{
	# will be really daemonized by our internal target 'background'
	daemon --check $NAME --pidfile $PIDFILE $0 background

	return $?
}

agent_stop()
{
	echo -n "Stopping $DESC: "
	killproc -p $PIDFILE $DAEMON -TERM
	RETVAL=$?
	echo
	[ $RETVAL -eq 0 ] && rm -f $PIDFILE

	return $RETVAL
}

case "$1" in
  start)
	echo -n "Starting $DESC: "
	agent_start
	echo
	;;
  stop)
	agent_stop
	;;
  status)
	status -p $PIDFILE $DAEMON && exit 0 || exit $?
	;;
  restart)
	agent_stop
	if [ "$?" -eq 0 ]; then
		echo -n "Restarting $DESC: "
		agent_start
		RETVAL=$?
		echo
	fi
	;;
  reload)
	echo -n "Reloading $DESC: "
	killproc -p $PIDFILE $DAEMON -HUP
	RETVAL=$?
	echo
	;;
  background)
  	# As RHs don't have Debian's start-stop-daemon (or equivalent binary),
	# had to reinvent bicycle wheels in MAGIC SMILEYS of pure sh ;-)
    DIRFULLPATH=`readlink -f $WORKDIR`
	cd $DIRFULLPATH || { logger -i -s -t $0 "Error: can\'t cd to $DIRFULLPATH"; exit 2; }
	# give a best try to make a true daemon if have setsid from util-linux[-ng]
	setsid=
	[ -x /usr/bin/setsid ] && setsid=/usr/bin/setsid
	( ( trap ':' HUP; exec $setsid /bin/sh -c "echo \$\$ > $PIDFILE; exec $DAEMON" ) >/dev/null 2>&1 <&1 & )
	;;
  *)
	echo "Usage: $0 {start|stop|status|reload|restart}" >&2
	exit 3
	;;
esac

exit $RETVAL
