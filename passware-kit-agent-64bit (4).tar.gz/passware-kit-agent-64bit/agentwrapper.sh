#!/bin/sh

# Copyright (c) 2014-2021 Passware

# configuration settings
BINPATH=.
BINNAME=passware-kit-agent
CONFIGPATH=.
CONFIGNAME=agent.conf
CONFIGFULLPATH=`readlink -f $CONFIGPATH/$CONFIGNAME`
ARGS="-c $CONFIGFULLPATH"

UPDATE_FOLDER=`sed -n 's/^[[:space:]]*UpdatesFolder[[:space:]]=[[:space:]]\(.*\)/\1/p' $CONFIGFULLPATH`
CORRUPTED_UPDATES_SUBFOLDERS=""

# error codes
EX_OK=0                 # successful termination
EX_USAGE=64             # command line usage error
EX_DATAERR=65           # data format error
EX_OSERR=71             # system error (e.g., can't fork)
EX_CONFIG=78            # configuration error
EX_RESTARTREQUIRED=79   # agent should be restarted
EX_RUNUPDATEDVERSION=80 # an updated version of agent should be launched

ENETRESET=102

test -x $BINNAME        || { logger -i -s -t $BINNAME "Error: $BINNAME not found or not executable";      exit 5; }
test -r $CONFIGFULLPATH || { logger -i -s -t $BINNAME "Error: $CONFIGFULLPATH not found or not readable"; exit 5; }

is_corrupted_subfolder()
{ 
    if echo "${CORRUPTED_UPDATES_SUBFOLDERS}" | grep -q "$1"; then
        return 1
    fi

    return 0
}

find_latest_update_folder()
{
    local bin_path='.'
    for subfolder in `ls -d $UPDATE_FOLDER/* 2> /dev/null | sort -r`
    do
        if [ -d $subfolder ]; then
            is_corrupted_subfolder "$subfolder"
            if [ $? = 0 -a -x "$subfolder/$BINNAME" ]; then
                bin_path=$subfolder
                break
            fi
        fi
    done

    BINPATH=$bin_path
}

# config end, start work
coreBINNAME=`echo $BINNAME | cut -c 1-15`       # Linux kernel strips too long %e in core_pattern
ulimit -c unlimited                # enable coredumps for us/children

# We propagate caught signals to entire our process group - including this
# script's process, too - so put a guard against infinite signal loop.
handle()
{
    if [ -z "$caught" ]; then
        caught=$1
        kill -$1 0
    fi
}
for _sig in HUP INT QUIT TERM USR1 USR2; do
    eval trap "'handle $_sig'" $_sig
done

# start main loop
running=1
failures=0

while [ $running -ne 0 ]; do
    find_latest_update_folder
    CMD=`readlink -f $BINPATH/$BINNAME`

    if [ ! -x "$CMD" ]; then
        { logger -i -s -t $BINNAME "Error: $CMD not found or not executable";
        exit 127; }
    fi

    seconds_before=$SECONDS

    caught=""
    $CMD $ARGS $coredump_arg "$@" &
    lastpid=$!

    echo 0x17 > /proc/$lastpid/coredump_filter
    wait $lastpid

    errcode=$?

    # When bash is waiting for an asynchronous command via the 'wait'
    # builtin, the reception of a signal for which a trap has been set
    # will cause the 'wait' builtin to return immediately with an exit
    # status greater than 128, immediately after which the trap is executed.
    # Also, exit code is either from program itself, if less 127, or it
    # is 128+signal number, if killed by signal, BUT! we're in sh, so:
    # we've no separate core dump flag (as opposed to wait4() info), and
    # program may exit itself with e.g. code 255 - no signal! so guess...
    if [ $errcode = $EX_RESTARTREQUIRED ]; then
        # restart agent, continue
        :
    elif [ $errcode = $EX_RUNUPDATEDVERSION ]; then
        # make newer agent executable
        newer_agent=`readlink -f $UPDATE_FOLDER/$BINNAME`
        chmod +x $newer_agent

        # move update files into subfolder with folder_name = agent_version
        version=`$newer_agent --version | sed -n 's/.*\([[:digit:]]\{4\}\.[[:digit:]]\.[[:digit:]]\)[[:space:]]*\([[:digit:]]\{2\}-bit\)[^[:digit:]]*\([[:digit:]]\+\)/\1.\3.\2/p'`
        if [ -z $version ]; then
            version=latest
        fi
        version_specific_update_folder=$UPDATE_FOLDER/$version

        [ -d $version_specific_update_folder ] || mkdir -p $version_specific_update_folder
        find $UPDATE_FOLDER -maxdepth 1 -type f -exec mv {} $version_specific_update_folder \;
    elif [ "$caught" = "INT" -o "$caught" = "TERM" -o "$caught" = "QUIT" ];then
        running=0
    elif [ $errcode -lt 128 -a $errcode -ne $ENETRESET ]; then
        if [ $(( SECONDS - seconds_before )) -lt 60 ]; then
            # debug
            echo Failure!
            (( failures++ ))
        fi

        if [ $failures -lt 5 ]; then
            continue
        fi

        if [ ! $BINPATH = '.' ]; then
            CORRUPTED_UPDATES_SUBFOLDERS="${BINPATH};${CORRUPTED_UPDATES_SUBFOLDERS}"
            failures=0
            continue
        fi

        running=0
    elif [ $errcode -ge 128 -a -n "$caught" ]; then
        # currently on reconfig sigs we just restart agent w/no coredump arg
        sleep 1
    else
        coredump_arg=
        # NB: same --core-dump for several HUP restarts is currently
        # intended: we don't know if it was really sent to server on time
        corefile=`find . -name "core.*.$coreBINNAME*.*$lastpid" | head -1`
        default_corefile=`find . -name "core" | head -1`

        if [ -n "$corefile"  ]; then
            core_full_path=`readlink -f $corefile`
        elif [ -n "$default_corefile"  ]; then
            core_full_path=`readlink -f $default_corefile`
        fi
        coredump_arg="--core-dump \"$core_full_path\""
    fi
done
